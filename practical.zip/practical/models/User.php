<?php

class User
{
    // users table property
    public $id;
    public $username;
    public $password;
	
}