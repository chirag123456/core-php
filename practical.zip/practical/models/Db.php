<?php

class Db{
    public $host = 'localhost';
    public $username = 'root';
    public $password = '12345678';
    public $database = 'pixometry';
    public $con;

    public function __construct(){

    }

    /**
     * connect db
     * @return mysqli
     */
    public function connect(){

        $this->con = mysqli_connect($this->host,$this->username,$this->password,$this->database);

        if (mysqli_connect_errno())
        {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
        }

        return $this->con;
    }

    /**
     * execute query
     * @param $query
     * @return bool|mysqli_result
     */
    public function query($query){
        $array = mysqli_query($this->con,$query) or die('Error querying the Database');
        return $array;
    }

    /**
     * fetch result
     * @param $result
     * @return array|null
     */
    public function fetch($result)
    {
		for ($rows = array (); $rows = mysqli_fetch_assoc($result); $set[] = $rows);
        return $set;
    }

    /**
     * mysql connection close
     * @return bool
     */
    public function close(){
        return mysqli_close($this->con);
    }
}
