
<?php

class Product
{
    // property of tables
    public $id;
    public $name;
    public $product_code;
    public $description;
    public $price;
    public $created_at;
    public $updated_at;


}
