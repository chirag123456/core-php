<?php
require_once "Db.php";
class DataMaster
{
    /**
     * user login
     */
    public function login($username, $password){
        $db = new Db();
        $db->connect();
        $result = $db->query("select * from users where  BINARY `username` = '" . $username . "' and BINARY `password` = '" .$password. "'");
        // set user data in session
        $res= $db->fetch($result);
        if($res)
        {
            session_start();
            $_SESSION['userid']=$res[0]['id'];
            header('location:products.php');
        }
        else
        {
            echo'You entered username or password is incorrect';
        }
    }
    /**
     * Add product
     */
    public function addProduct($name,$pcode,$pdescription,$price){
        $db = new Db();
        $db->connect();
        $result = $db->query("insert into `product`(`pname`,`pcode`,`pdescription`,`price`)VALUES('$name','$pcode','$pdescription','$price')");
        return $result;
    }
    /**
     * edit product
     */
    public function editProduct($id,$name,$pcode,$pdescription,$price){
        $db = new Db();
        $db->connect();
        $result = $db->query("update `product` set pname='$name',pcode='$pcode',pdescription='$pdescription',price='$price' where id='$id'");
        return $result;
    }
    /**
     * get products list
     */
    public function getProducts(){
		$db = new Db();
		$db->connect();
		$result = $db->query("select * from product");
		$rows = $db->fetch($result);
		return $rows;
    }
    public function getProducts_id($id){
        $db = new Db();
        $db->connect();
        $result = $db->query("select * from product where id=$id");
        $rows = $db->fetch($result);
        return $rows;
    }
    /**
     * Delete product
     */
    public function deleteProduct($del_id){
        $db = new Db();
        $db->connect();
        $result = $db->query("delete from product where id=$del_id");
        return $result;
    }
}