<?php
session_start();
if(!$_SESSION){
    header('location:login.php');
}
require_once 'models/DataMaster.php';
$insertdata = new  DataMaster();

if(isset($_GET['del_id']))
{
    $result = $insertdata->deleteProduct($_GET['del_id']);
    if($result)
    {
        header('Location:products.php');
    }
    else
    {
        echo "<script>alert('Data is not deleted');</script>";
    }
}
if(isset($_GET['id']))
{
    $result = $insertdata->getProducts_id($_GET['id']);
}
if(isset($_POST['submit']))
{
    $name=$_POST['name'];
    $pcode=$_POST['pcode'];
    $pdescription=$_POST['pdescription'];
    $price=$_POST['price'];
    $id=$_POST['id'];
    if($id) {
        $sql = $insertdata->editProduct($id, $name, $pcode, $pdescription, $price);
    }
    else {
        $sql=$insertdata->addProduct($name,$pcode,$pdescription,$price);
    }
    if($sql)
    {
        header('Location:products.php');
    }
    else
    {
        echo "<script>alert('Data is not proceed');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<body id="page-top" class="index">
<!-- Navigation -->
<?php require_once '_header.php'?>
<section id="contact">
    <div class="container">
        <div class="row">
            <div class="">
                <a href="products.php" class="btn btn-primary">Go to List Product</a>
            </div>
        </div>
        </br>
        </br>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">Add Products</h4>
            </div>
               </br>
            </br>
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <form  id="myform" method="post" action="" name="addProduct">
                    <div class="row control-group">
                        <div class="form-group col-xs-12 floating-label-form-group controls">
                            <label>Name</label>
                            <input type="hidden" name="id" value="<?php echo $_GET['id'];?>">
                            <input type="text" class="form-control required" placeholder="ProductName" id="name" name="name" value="<?php echo $result[0]['pname']; ?>">
                            <p class="help-block text-danger"></p>
                        </div>
                    </div>
                    <div class="row control-group">
                        <div class="form-group col-xs-12 floating-label-form-group controls">
                            <label>Product Code</label>
                            <input type="text" class="form-control required" placeholder="Product code" id="product_code" name="pcode" value="<?php echo $result[0]['pcode']; ?>">
                            <p class="help-block text-danger"></p>
                        </div>
                    </div>
                    <div class="row control-group">
                        <div class="form-group col-xs-12 floating-label-form-group controls">
                            <label>Description</label>
                            <input type="text" class="form-control required" placeholder="Description" id="description" name="pdescription" value="<?php echo $result[0]['pdescription']; ?>">
                            <p class="help-block text-danger"></p>
                        </div>
                    </div>
                    <div class="row control-group">
                        <div class="form-group col-xs-12 floating-label-form-group controls">
                            <label>Price</label>
                            <input type="text" class="form-control required digits" placeholder="Price" id="price" name="price" value="<?php echo $result[0]['price']; ?>">
                            <p class="help-block text-danger"></p>
                        </div>
                    </div>
                    <br>
                    <div class="row control-group">
                        <div class="form-group col-xs-12 text-right">
                            <input type="submit" class="btn btn-success btn-lg" name="submit" value="Submit">
                        </div>
                    </div>
                </form>
            </div>
            <div class="clearfix"></div>
        </div>
        </div>
    </div>
</section>
<?php require_once '_footer.php'?>
<?php require_once '_script.php'?>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $("#price").keypress(function (e) {
            if (e.which != 8 && e.which != 0 &&  (e.which < 45 || e.which > 57)) {
                return false;
            }
        });
    });
    $( "#myform" ).validate({
            rules: {
                        name: {
                                 required: true
                              },
                        pcode:{
                                required: true
                              },
                        pdescription:{
                                       required: true
                                     },
                        price:{
                                required: true,
                                numbers: true
                              }
                    }
               });


</script>
</body>
</html>
