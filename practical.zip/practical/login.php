<?php
require_once 'models/DataMaster.php';
if($_POST){
    $dataMaster = new DataMaster();
    $login = $dataMaster->login($_POST['username'],$_POST['password']);

    if($login){
        header("Location:products.php");
    }else{
        echo "Enter correct username or password";// display msg of invalid login
    }

}
?>
<!DOCTYPE html>
<html lang="en">
    <?php require_once '_script.php'?>
    <body id="page-top" class="index">
    <!-- Navigation -->
    <?php require_once '_header.php'?>

        <section id="contact">
            <div class="container">

                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h2>Login</h2>
                        <hr class="star-primary">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <form name="login" id="login" method="post" action="">
                            <div class="row control-group">
                                <div class="form-group col-xs-12 floating-label-form-group controls">
                                    <label>Username</label>
                                    <input type="text" class="form-control" placeholder="Username" id="username" name="username">
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="row control-group">
                                <div class="form-group col-xs-12 floating-label-form-group controls">
                                    <label>Email Address</label>
                                    <input type="password" class="form-control" placeholder="Password" id="password" name="password">
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <br>
                            <div class="row control-group">
                                <div class="form-group col-xs-12 text-right">
                                    <button type="submit" class="btn btn-success btn-lg">Login</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </section>
        <?php require_once '_footer.php'?>
    </body>

</html>
