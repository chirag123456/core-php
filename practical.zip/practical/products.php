<?php

session_start();
if(!$_SESSION){
    header('location:login.php');
}
require_once 'models/DataMaster.php';
$getdata = new  DataMaster();
$res=$getdata->getProducts();

$table="product";



?>
<!DOCTYPE html>
<html lang="en">
<?php require_once '_script.php'?>
<body id="page-top" class="index">

<!-- Navigation -->
<?php require_once '_header.php'?>
<section id="contact">
    <div class="container">
        <div class="row">
            <div class="">
                <a href="addproduct.php" class="btn btn-primary"> Add Product</a>
            </div>

            <br>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Products</h3>
                </div>
                <div class="panel-body">
                    <table border="1" class="table">

                        <thead>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Code</th>
                        <th>Price</th>
                        <th>Edit/Delete</th>
                        </thead>
                        <tbody>
                        <?php


                        foreach ($res as $row)
                        {
                        ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['pname']; ?></td>
                            <td><?php echo $row['pcode']; ?></td>
                            <td><?php echo $row['price']; ?></td>
                            <td><a href="addproduct.php?id=<?php echo $row[id]; ?>" class="btn btn-default">Edit</a>
                                <a href="addproduct.php?del_id=<?php echo $row[id]; ?>" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                            <?php
                        }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</section>
<?php require_once '_footer.php'?>
</body>

</html>
