<?php
session_start();
if(!$_SESSION){
header('location:login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<?php require_once '_script.php'?>
<body id="page-top" class="index">

<!-- Navigation -->
<?php require_once '_header.php'?>
<section id="contact">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div><h3>Pages</h3></div>
                <ul class="list-group">
                    <li class="list-group-item"><a href="products.php">Products</a></li>
                </ul>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</section>
<?php require_once '_footer.php'?>
</body>

</html>
